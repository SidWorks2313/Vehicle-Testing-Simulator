# Proving Ground Simulator · ADAS Suite

Single-file, browser-based (Three.js) proving ground simulator with the full ADAS driver-assistance suite
(emergency braking, adaptive cruise, traffic sign recognition, blind-spot monitoring, traffic jam assist,
cross-traffic alert, automatic headlights, V2X trials and automatic parking) for all vehicle models.

## Run locally
Open `index.html` in a modern browser (Chrome / Edge recommended). Internet is needed only for Google Fonts.

## Deploy on GitHub Pages
1. Push this folder to a GitHub repository (branch `main`).
2. Repo **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Each push to `main` deploys automatically; the site is at `https://<user>.github.io/<repo>/`.
